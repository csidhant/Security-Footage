import re
import os

def extract_jpegs(raw_file, output_dir):
    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)

    with open(raw_file, 'rb') as f:
        data = f.read()

    # Split by boundary
    parts = data.split(b'--BoundaryString')
    for i, part in enumerate(parts):
        if b'JFIF' in part:  # Check for JPEG data
            # Extract JPEG content after headers
            jpeg_start = part.find(b'\xFF\xD8')
            jpeg_end = part.rfind(b'\xFF\xD9') + 2
            if jpeg_start != -1 and jpeg_end != -1:
                jpeg_data = part[jpeg_start:jpeg_end]
                output_path = os.path.join(output_dir, f'frame_{i}.jpg')
                with open(output_path, 'wb') as img:
                    img.write(jpeg_data)

# Use the current folder (frames) for both input and output
extract_jpegs('stream.raw', '.')  # '.' means current folder
